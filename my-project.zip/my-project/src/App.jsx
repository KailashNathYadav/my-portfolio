import React from 'react'
import {Navbar,Hero,Skills,Experience,Certificates,Education,Projects,Contact,Footer} from './index.js'

const App = () => {
  return (
    <>
    <Navbar />
    <Hero />
    <Skills />
    <Experience />
    <Certificates />
    <Education />
    <Projects />
    <Contact />
    <Footer />
    </>
  )
}

export default App
