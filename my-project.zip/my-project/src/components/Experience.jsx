import React from 'react'
import ExperienceDataCard from './ExperienceDataCard';

export const experienceData = [
  {
    id:1,
    dataNum: "0+",
    dataType: ["years","Experience"]
  },{
    id:2,
    dataNum: "9+",
    dataType: ["completed","Projects"]
  },{
    id:3,
    dataNum: "1+",
    dataType: ["companies","Work"]
  }
]

const Experience = ({prop}) => {
  return (
    <div className='section-gap' id="experience">
      {experienceData.map((data,id)=>{
        return (
          <ExperienceDataCard prop={data} />
        );
      })}
    </div>
  )
}

export default Experience
