import React from 'react'

const ExperienceDataCard = ({prop}) => {
  return (
    <div className='mt-5 size-80'>
      <div className="mt-1 size-60 rounded-full bg-green-500 mx-auto text-8xl flex justify-center items-center font-bold">{prop.dataNum}</div>
      <div className='mt-1 text-xl flex justify-center'>{prop.dataType[0]}</div>
      <div className='mt-1 font-bold text-green-700 text-3xl flex justify-center'>{prop.dataType[1]}</div>
    </div>
  )
}

export default ExperienceDataCard
