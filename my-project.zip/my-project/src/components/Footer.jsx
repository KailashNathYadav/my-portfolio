import React from 'react'
import ContactIcons from './ContactIcons'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faArrowUp } from '@fortawesome/free-solid-svg-icons'

const Footer = () => {
  return (
    <div className='mt-5 bg-green-700 h-[15vh] flex flex-col gap-1'>
      <div className='mx-auto mt-1'>
      <ContactIcons />
      </div>
      <div className='flex'>
        <div className='h-8 mx-auto'>&copy; Developed with ❤️ by Kailash Nath Yadav @{new Date().getFullYear()}.</div>
        <a href="#navbar" ><FontAwesomeIcon icon={faArrowUp} className='mr-3 p-2 size-3 rounded-3xl bg-green-300'/></a>
      </div>
    </div>
  )
}

export default Footer
