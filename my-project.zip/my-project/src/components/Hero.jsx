import React from 'react'
import myImg from '../assets/images/my-photo.jpg';
import ContactIcons from './ContactIcons';
import myResume from '../assets/my-resume.pdf';


const Hero = () => {
  return (
    <div className='section-gap' id="about">
      <img src={myImg} className='w-[22vw] h-100 border-8 border-l-0 rounded-md' />
      <ul className='w-[22vw] h-100 border-8 border-l-0 bg-green-700 flex flex-col rounded-md'>
        <li className='ml-2 mt-2 text-white text-2xl font-bold'>Kailash Nath Yadav</li>
        <li className='ml-2 mt-2 text-md'>Working as: SDE</li>
        <li className='ml-2 mt-2 text-md'>Current Company: NICS Technology</li>
        <li className='ml-2 mt-2 text-md'>Education: B.Tech(CSE)</li>
        <li className='ml-2 mt-2 text-md'>From: Sultanpur UP</li>
        <li className='ml-2 mt-2 text-md'>Live In: Noida UP</li>
        <li className='ml-2 mt-2 text-md'>DOB: 16/08/1999</li>
        <li className='ml-2 mt-2 text-md'>Gender: Male</li>
        <li className='ml-2 mt-2 text-md'>Email: satyamy866@gmail.com</li>
        <li className='ml-2 mt-2 text-md'>Phone No: 7355594971</li>
        <a href={myResume} download className='ml-2 mt-2 text-lg bg-green-500 mx-auto p-1 rounded-xl hover:bg-green-300'>Download CV</a>
      </ul>
      <div className='w-[22vw] h-100 border-8 border-l-0 bg-green-700 flex flex-col rounded-md'>
        <h1 className='text-2xl font-bold ml-2 text-white'>Hi! I am Kailash Yadav</h1>
        <p className='text-md mb-5 ml-2 leading-8'>I am a Software Developer & Web Developer with 0+ years of experience. I did B.Tech(CSE) from HR Institute of Technology Gzb. Currently I am working in NICS Technology as a Software Developer. Now I am looking for the Software/Web Developer position in another company. If anyone wants to hire me, please contact me.</p>
        <div className='flex gap-2 mx-1 mb-1'>
          <a href="#contact" className='px-1 rounded-md bg-green-500 hover:bg-green-300'>Hire Me</a>
          <ContactIcons />
        </div>
      </div>
    </div>
  )
}

export default Hero
