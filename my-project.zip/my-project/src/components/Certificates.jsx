import React from 'react'
import CertificateCard from './CertificateCard'

export const myCertificates = [
  {
    id:1,
    name: "BackEnd Software Development",
    issuedBy: "Great Learning & IIT Roorkee",
    url: "https://eict.iitr.ac.in/wp-content/uploads/IITR-GL-BE-N2M-23-11-scaled.jpg",
    about: "In this course we covered various topics required in backend development: Git & Github, Core Java, OOPs, Multithreading, Exception Handling, File Handling, Java Collection Framework, Functional Programming, MySQL, MongoDB, JDBC, Hibernate, JPA, Spring MVC, Spring Boot, REST API, Postman & Talend."
  },{
    id:2,
    name: "MicroServices Using Spring Boot & Cloud",
    issuedBy: "Udemy",
    url: "https://www.udemy.com/certificate/UC-a13a3428-7ddb-4cef-8daa-3730f11c1590/",
    about: "Microservices Using Spring Boot & Spring Cloud is a focused course thats covers the utilization of Spring Boot and Spring Cloud frameworks to design, deploy, and manage microservices architecture efficiently. Learn key concepts such as service discovery, communication, configuration management & deployment."
  },{
    id:3,
    name: "Complete Web Development BootCamp",
    issuedBy: "Udemy",
    url: "https://www.udemy.com/certificate/UC-cd06aaf7-71ec-42e3-b56e-2e7fbef567f3/",
    about: "FullStack Using MERN: MongoDB for nosql database , ExpressJs & NodeJS for server side development aka backend, ReactJS for UI aka frontend. Along with these things also learn html, css, javascript , bootstrap, tailwind css which makes a strong base for MERN techstack which is widely used for making production application."
  }
]

const Certificates = () => {
  return (
    <div className='section-gap' id="certificates">
      {myCertificates.map((certificate,id)=>{
        return (
          <CertificateCard prop={certificate} />
        );
      })}
    </div>
  )
}

export default Certificates
