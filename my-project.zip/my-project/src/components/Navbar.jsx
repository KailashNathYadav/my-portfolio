import React from 'react'

const Navbar = () => {
  return (
    <nav className='bg-green-700 w-[99vw] h-10 flex items-center px-2' id="navbar">
      <div className='mr-auto'>
      <span className='text-black-500 font-bold'>KN </span>
      <span className='text-green-300 font-bold'>Yadav</span>
      </div>
      <ul className='flex justify-end gap-4'>
        <li><a href="#about" className="hover:bg-green-300 rounded p-1">About Me</a></li>
        <li><a href="#skills" className="hover:bg-green-300 rounded p-1">Skills</a></li>
        <li><a href="#experience" className="hover:bg-green-300 rounded p-1">Experience</a></li>
        <li><a href="#certificates" className="hover:bg-green-300 rounded p-1">Certificates</a></li>
        <li><a href="#education" className="hover:bg-green-300 rounded p-1">Education</a></li>
        <li><a href="#projects" className="hover:bg-green-300 rounded p-1">Projects</a></li>
        <li><a href="#contact" className="hover:bg-green-300 rounded p-1">Contact Me</a></li>
      </ul>
    </nav>
  )
}

export default Navbar
