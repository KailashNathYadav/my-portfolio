import React from 'react'

const Contact = () => {
  return (
    <div className='section-gap' id="contact">
      <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3503.6398447433007!2d77.3099529754989!3d28.580575775693227!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce45c38e9d9e5%3A0x92f73d2468b6d519!2sGali%20Number%202%2C%20Sector%2015%2C%20Noida%2C%20Uttar%20Pradesh!5e0!3m2!1sen!2sin!4v1711436353336!5m2!1sen!2sin" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade" className='h-[35vw] w-[48vw] mx-[1vw]'></iframe>
      <form action="https://api.web3forms.com/submit" method="POST" className='flex flex-col bg-green-700 p-5'>
        <input type="hidden" name="access_key" value="fd00e6bb-f206-4747-8fad-7c5a231fc71f" />
        <input type="text" name="name:" placeholder='Name'  className='mt-5 bg-green-300 p-1 rounded-md' />
        <input type="text" name="mobile No:" placeholder='Mobile No'  className='mt-5 bg-green-300 p-1 rounded-md' />
        <input type="email" name="email:" placeholder='Email'  className='mt-5 bg-green-300 p-1 rounded-md' />
        <textarea type="text"  name="message:" rows="8" cols="80" placeholder='Message' className='mt-5 bg-green-300 p-1 rounded-md' />
        <input type="submit" value="Submit" className='mt-5 bg-green-500 p-1 rounded-md'/>
      </form>
    </div>
  )
}

export default Contact
