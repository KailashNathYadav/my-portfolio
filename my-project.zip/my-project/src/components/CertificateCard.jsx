import React from 'react'

const CertificateCard = ({prop}) => {
  return (
    <div className='flex flex-col bg-green-700 rounded-2xl size-80'>
      <h1 className='mx-2 text-white font-bold text-2xl'>{prop.name}</h1>
      <p className='mx-2 mt-0.5 text-xl bold'>{prop.issuedBy}</p>
      <p className='mx-2 mt-0.5'>{prop.about}</p>
      <a href={prop.url} className='mx-2 mt-0.5 bg-green-300 px-1 rounded-3xl'>Certificate Link</a>
    </div>
  )
}

export default CertificateCard
