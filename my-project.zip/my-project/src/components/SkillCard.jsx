import React from 'react'
import { mySkills } from './Skills';

const SkillCard = ({prop}) => {
  return (
    <div className='size-80 bg-green-700 p-1 rounded-2xl'>
      <h1 className='font-bold flex justify-center text-2xl mb-1 text-white ml-2'>{prop.skill}</h1>
      <p className='mb-1 ml-2'>{prop.about}</p>
      <p className='bold mb-1 ml-2'>Level :  {prop.level}</p>
      <a className='bold  flex ml-2 hover:text-hover-300 rounded-3xl px-1 bg-green-300'>more ...</a>
    </div>
  )
}

export default SkillCard;
