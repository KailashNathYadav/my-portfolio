import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faGithub, faLinkedin, faFacebook } from '@fortawesome/free-brands-svg-icons';
import { faEnvelope } from '@fortawesome/free-regular-svg-icons';

const ContactIcons = () => {
  return (
    <div className='flex gap-2'>
          <a href="https://github.com/KailashNathYadav" target='_blank' className='size-auto p-1 rounded-md bg-green-500 hover:bg-green-300'>
            <FontAwesomeIcon icon={faGithub} className='icon' />
          </a>
          <a href="https://www.linkedin.com/in/kailash-nath-yadav-6a3176218/" target='_blank' className='w-auto p-1 rounded-md bg-green-500 hover:bg-green-300'>
            <FontAwesomeIcon icon={faLinkedin} className='icon' />
          </a>
          <a href="https://mail.google.com/mail/u/0/#inbox?compose=satyamy866@gmail.com" target='_blank' className='w-auto p-1 rounded-md bg-green-500 hover:bg-green-300'>
            <FontAwesomeIcon icon={faEnvelope} className='icon' />
          </a>
          <a href="https://www.facebook.com/kailashnath.yadav.733/about" target='_blank' className='w-auto p-1 rounded-md bg-green-500 hover:bg-green-300'>
            <FontAwesomeIcon icon={faFacebook} className='icon' />
          </a>
        </div>
  )
}

export default ContactIcons
