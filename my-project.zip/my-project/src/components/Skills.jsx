import React from 'react'
import SkillCard from './SkillCard'

export const mySkills = [
  {
    id:1,
    skill: "Problem Solving",
    about: "DSA using Python: I Learned various data structure like array, linked list, stack, queue, heap, set, map, tree, graph as well as many algorithm like sorting, searching, divide and conquer, two pointer, sliding window, pre-processing, recursion, backtracking, dynamic programming, depth first search, breadth first search, topological sort, MST, union-find.",
    level: "Intermediate",
    links: ["https://leetcode.com/satyamy866/",
            "https://auth.geeksforgeeks.org/user/satyamy866",
            "https://www.hackerrank.com/profile/satyamy866"],
  },{
    id:2,
    skill: "FullStack Development",
    about: "FullStack Using MERN: MongoDB for nosql database , ExpressJs & NodeJS for server side development aka backend, ReactJS for UI aka frontend. Along with these things also learn html, css, javascript , bootstrap, tailwind css, material ui which makes a strong base for MERN tech-stack which is widely used for making production level application.",
    level: "Intermediate",
    links: ["https://www.udemy.com/certificate/UC-cd06aaf7-71ec-42e3-b56e-2e7fbef567f3/"],
  },{
    id:3,
    skill: "Backend Development",
    about: "Backend Development using Java & Spring Boot: Topic included are - Core Java, OOPs, Java Collection Framework, Multithreading, Exceptional Handling, JDBC, Hibernate, JPA, MySQL, MongoDB, Spring MVC, Spring Boot, Talend, Postman, REST API, Design Principle (SOLID principle), Design Pattern (Creational, Structural, Behaviour) & Microservices.",
    level: "Intermediate",
    links: ["https://eict.iitr.ac.in/wp-content/uploads/IITR-GL-BE-N2M-23-11-scaled.jpg","https://www.udemy.com/certificate/UC-a13a3428-7ddb-4cef-8daa-3730f11c1590/"],
  }
]

const Skills = () => {
  return (
    <div className='section-gap' id="skills">
      {mySkills.map((skill,id)=>{
        return (
          <SkillCard prop={skill}/>
        );
      })}
    </div>
  )
}

export default Skills
