import React from 'react'

const EducationDetailCard = ({prop}) => {
  return (
    <div className='flex flex-col bg-green-500 size-60 rounded-full justify-center items-center p-1'>
      <h1 className='mt-1 text-white text-2xl font-bold'>{prop.education}</h1>
      <p className='mt-1'>{prop.course} : {prop.percentage}</p>
      <p className='mt-1'>{prop.institute}</p>
      <p className='mt-1'>Duration: {prop.duration}</p>
      <a href={prop.instituteWebsite} className='mx-1 mt-1'>Institute Website</a>
    </div>
  )
}

export default EducationDetailCard
