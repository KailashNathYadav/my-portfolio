import React from 'react'
import EducationDetailCard from './EducationDetailCard';

export const myEducation = [
  {
    id:1,
    education: "Graduation",
    course: "B.Tech(CSE)",
    percentage: "80 %",
    institute: "HR Institute of Technology , Morta Ghaziabad  (A.K.T.U)",
    duration: "2018 - 2022",
    instituteWebsite: "https://www.hrit.ac.in/"
  },{
    id:2,
    education: "Intermediate/12th",
    course: "PCM",
    percentage: "73 %",
    institute: "RSYSIC, Baba Bazar Bhawanipur Rudauli Ayodhya (UP Board)",
    duration: "2016 - 2017",
    instituteWebsite: "https://rsysic.org/"
  },{
    id:3,
    education: "High School/10th",
    course: "PCMB",
    percentage: "85 %",
    institute: "KKSVM, Mayang Majhwara Sultanpur (UP Board)",
    duration: "2014 - 2015",
    instituteWebsite: "https://kksvmic.github.io/"
  }
]

const Education = () => {
  return (
    <div className='section-gap' id="education">
      {myEducation.map((data,id)=>{
        return (
          <EducationDetailCard prop={data} />
        );
      })}
    </div>
  )
}

export default Education
