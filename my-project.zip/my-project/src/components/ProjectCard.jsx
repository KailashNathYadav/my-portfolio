import React from 'react'

const ProjectCard = ({prop}) => {
  return (
    <div className='flex flex-col size-80 bg-green-700 rounded-2xl'>
      <h1 className='mx-2 mt-0.5 text-2xl text-white flex justify-center font-bold'>{prop.title}</h1>
      <h1 className='mx-2 mt-0.5'>Status: {prop.status}</h1>
      <h1 className='mx-2 mt-1'>{prop.techstack}</h1>
      <h1 className='mx-2 mt-1'>{prop.details}</h1>
      <h1 className='mx-2 mt-1'>Duration: {prop.duration}</h1>
      <a href={prop.link} className='mx-2 mt-1 px-1 bg-green-300 rounded-3xl'>Project Link</a>
    </div>
  )
}

export default ProjectCard
