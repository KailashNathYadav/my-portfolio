import React from 'react'
import ProjectCard from './ProjectCard'

export const myProjects = [
  {
    id:1,
    title: "My Portfolio",
    status: "Working",
    techstack: "HTML, CSS, JS, TailwindCSS, ReactJS",
    duration: "March 2024 - April 2024",
    details: "I created portfolio website to demonstrate my skill, expertise, projects, certification, education, and contact details.If anyone is interested in my profile, he/she can easily download my resume & also can contact me via phone, email, or any social media site like linkedin, instragram.",
    link: "https://github.com/KailashNathYadav/",
  },{
    id:2,
    title:"Student Mgmt App.",
    status: "Completed",
    techstack: "Java, JPA, Spring Boot, Thymeleaf, Maven, MVC design pattern.",
    duration: "June 2023 - July 2023",
    details: "Created a dynamic web project using Spring MVC and Thymeleaf for student information management. Implemented Create, Read, Update, Delete aka CRUD operations and integrated search functionality based on name.",
    link: "https://github.com/KailashNathYadav/SMS",
  },{
    id:3,
    title: "Calculator Using ReactJs",
    status: "Completed",
    techstack: "HTML, Vanilla CSS, JavaScript, ReactJS.",
    duration: "July 2023 - Aug 2023",
    details: "In this project, Calculator App is designed with the help of HTML and Vanilla CSS, functionality of performing various operations like - division , multiplication , addition , subtraction , and clearing the display text is done by JS and  ReactJS more precisely using hooks.",
    link: "https://github.com/KailashNathYadav/DMAS_APP",
  }
]

const Projects = () => {
  return (
    <div class="section-gap" id="projects">
      {myProjects.map((data,id)=>{
        return (
          <ProjectCard prop={data} />
        );
      })}
    </div>
  )
}

export default Projects
